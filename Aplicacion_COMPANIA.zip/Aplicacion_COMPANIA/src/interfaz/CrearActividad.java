/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Meli
 */
public class CrearActividad extends javax.swing.JFrame {
    public Connection con = null;
    /**
     * Creates new form CrearActividad
     */
    public CrearActividad() throws SQLException {
        initComponents();
        setLocation(400, 120);
        conectar();
    }

    public void conectar() throws SQLException{
        try {
            //conexion a ms sql 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");//esto siempre es igual
            String password = "12345678";
            String url = "jdbc:sqlserver://localhost;databaseName=BD_COMPANIA";

            con = DriverManager.getConnection(url,"root",password);
            System.out.println("Conectado a compania");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
            System.out.println("no se pudo conectar");
        }
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Descripcion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Pantalla = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        TipoFirma = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        RolSeguridad = new javax.swing.JComboBox<>();
        Requerida = new javax.swing.JCheckBox();
        jLabel7 = new javax.swing.JLabel();
        Tiempo = new javax.swing.JTextField();
        Periodica = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        TipoSeguridad = new javax.swing.JComboBox<>();
        Crear = new javax.swing.JToggleButton();
        Volver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setAutoscrolls(true);

        jLabel1.setFont(new java.awt.Font("Californian FB", 1, 24)); // NOI18N
        jLabel1.setText("Crear Actividad");
        jLabel1.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Nombre:");

        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Descripción:");

        Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescripcionActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Pantalla:");

        Pantalla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "No tiene", "Documentos", "Lista Chequeo" }));
        Pantalla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PantallaActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Tipo Firma:");

        TipoFirma.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sin Firma", "Firma Simple", "Firma Doble" }));
        TipoFirma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoFirmaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Rol de Seguridad:");

        RolSeguridad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Supervisor", "Líder", "Operario" }));
        RolSeguridad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RolSeguridadActionPerformed(evt);
            }
        });

        Requerida.setBackground(new java.awt.Color(204, 204, 255));
        Requerida.setText("Requerida");
        Requerida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RequeridaActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Tiempo en minutos:");

        Tiempo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TiempoActionPerformed(evt);
            }
        });

        Periodica.setBackground(new java.awt.Color(204, 204, 255));
        Periodica.setText("Periódica");
        Periodica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PeriodicaActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Tipo de Seguridad:");

        TipoSeguridad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ambos", "Calidad", "Producción" }));
        TipoSeguridad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoSeguridadActionPerformed(evt);
            }
        });

        Crear.setBackground(new java.awt.Color(255, 255, 153));
        Crear.setText("Crear");
        Crear.setAutoscrolls(true);
        Crear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearActionPerformed(evt);
            }
        });

        Volver.setBackground(new java.awt.Color(255, 255, 153));
        Volver.setText("Volver");
        Volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(Descripcion)
                                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Pantalla, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(TipoFirma, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(RolSeguridad, 0, 164, Short.MAX_VALUE)
                                .addComponent(TipoSeguridad, 0, 164, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Periodica)
                            .addComponent(Requerida))
                        .addGap(25, 25, 25))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Tiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Crear)
                .addGap(18, 18, 18)
                .addComponent(Volver)
                .addGap(44, 44, 44))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(Periodica)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Pantalla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Requerida)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TipoFirma, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(RolSeguridad, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TipoSeguridad, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Tiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Crear)
                    .addComponent(Volver))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescripcionActionPerformed

    private void TipoFirmaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoFirmaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoFirmaActionPerformed

    private void RolSeguridadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RolSeguridadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RolSeguridadActionPerformed

    private void RequeridaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RequeridaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RequeridaActionPerformed

    private void TiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TiempoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TiempoActionPerformed

    private void PeriodicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PeriodicaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PeriodicaActionPerformed

    private void TipoSeguridadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoSeguridadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoSeguridadActionPerformed

    private void CrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearActionPerformed
        String nombre = Nombre.getText();
        String descripcion = Descripcion.getText();
        String pantalla = Pantalla.getSelectedItem().toString();
        String tipo_firma = TipoFirma.getSelectedItem().toString();
        String rol_seguridad = RolSeguridad.getSelectedItem().toString();
        String tipo_seguridad = TipoSeguridad.getSelectedItem().toString();
        boolean periodica = Periodica.isSelected();
        boolean requerida = Requerida.isSelected();
        int tiempo;
        
        if(nombre.isEmpty() || descripcion.isEmpty() || Tiempo.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Ingrese todos los datos necesarios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        switch (tipo_firma){
            case "Sin Firma":
                tipo_firma = "N";
                break;
            case "Firma Simple":
                tipo_firma = "S";
                break;
            case "Firma Doble":
                tipo_firma = "D";
        }
        
        switch (rol_seguridad){
            case "Todos":
                rol_seguridad = "T";
                break;
            case "Supervisor":
                rol_seguridad = "S";
                break;
            case "Líder":
                rol_seguridad = "L";
                break;
            case "Operario":
                rol_seguridad = "O";
        }
        
        switch (tipo_seguridad){
            case "Ambos":
                tipo_seguridad = "A";
                break;
            case "Calidad":
                tipo_seguridad = "C";
                break;
            case "Producción":
                tipo_seguridad = "P";
        }
        
        
        try {
            tiempo = Integer.parseInt(Tiempo.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ingrese un numero en el tiempo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
            
        //si no requiere pantalla       
        if(pantalla.equals("No tiene")){
            CallableStatement call;
            ResultSet rs = null;
            
            try {/*
                call = con.prepareCall("{CALL CrearActividad(nombre => ?,descripcion => ?, tipo_firma => ?, rol_seguridad =>?, "
                        + "tipo_seguridad => ?, requerido => ?, tiempo_minutos => ?, periodica =>?)}");
                call.setNString("nombre", nombre);
                call.setNString("descripcion", descripcion);
                
                call.setNString("tipo_firma", tipo_firma);
                call.setNString("rol_seguridad", rol_seguridad);
                call.setNString("tipo_seguridad", tipo_seguridad);
                if(requerida)
                    call.setNString("requerido", "Y");
                else
                    call.setNString("requerido", "N");
                call.setInt("tiempo_minutos", tiempo);
                if(periodica)
                    call.setNString("periodica", "Y");
                else
                    call.setNString("periodica", "N");
                call.execute();*/
                
                call = con.prepareCall("{CALL CrearActividad(?,?,?,?,?,?,?,?,?)}");
                call.setNString(1, nombre);
                call.setNString(2, descripcion);
                call.setNull(3, java.sql.Types.INTEGER);
                call.setNString(4, tipo_firma);
                call.setNString(5, rol_seguridad);
                call.setNString(6, tipo_seguridad);
                if(requerida)
                    call.setNString(7, "Y");
                else
                    call.setNString(7, "N");
                call.setInt(8, tiempo);
                if(periodica)
                    call.setNString(9, "Y");
                else
                    call.setNString(9, "N");
                call.execute();
                
            } catch (SQLException ex) {
                Logger.getLogger(CrearActividad.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
        }
        
    }//GEN-LAST:event_CrearActionPerformed

    private void VolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VolverActionPerformed
        new Administrador().setVisible(true);
        dispose();
    }//GEN-LAST:event_VolverActionPerformed

    private void PantallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PantallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PantallaActionPerformed

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton Crear;
    private javax.swing.JTextField Descripcion;
    private javax.swing.JTextField Nombre;
    private javax.swing.JComboBox<String> Pantalla;
    private javax.swing.JCheckBox Periodica;
    private javax.swing.JCheckBox Requerida;
    private javax.swing.JComboBox<String> RolSeguridad;
    private javax.swing.JTextField Tiempo;
    private javax.swing.JComboBox<String> TipoFirma;
    private javax.swing.JComboBox<String> TipoSeguridad;
    private javax.swing.JButton Volver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
